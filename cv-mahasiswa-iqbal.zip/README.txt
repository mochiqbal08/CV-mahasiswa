# Website CV Mahasiswa

## Isi folder
- `index.html`: struktur dan isi website
- `style.css`: tampilan dan desain responsif
- `script.js`: menu mobile, tahun otomatis, dan tombol salin kontak
- `assets/profil.jpg.jpeg`: foto profil yang diberikan

## Cara melihat website
Klik dua kali `index.html`, atau buka folder ini melalui VS Code lalu gunakan ekstensi Live Server.

## Cara meng-online-kan lewat GitHub Pages
1. Buat akun atau masuk ke https://github.com/
2. Klik tombol `+` lalu pilih `New repository`.
3. Isi nama repository, misalnya `cv-mahasiswa`, pilih `Public`, lalu buat repository.
4. Unggah semua isi folder ini (bukan folder ZIP-nya): `index.html`, `style.css`, `script.js`, dan folder `assets` beserta foto.
5. Di repository, buka `Settings` → `Pages`.
6. Pada bagian Build and deployment, pilih `Deploy from a branch`.
7. Pilih branch `main` dan folder `/(root)`, lalu klik `Save`.
8. Tunggu beberapa menit. GitHub akan menampilkan alamat website di halaman Pages.

Catatan: ganti email, username GitHub, asal daerah, kampus, program studi, dan contoh proyek agar sesuai dengan data asli. Jangan unggah informasi pribadi yang tidak ingin dipublikasikan.
