const menuToggle = document.getElementById("menuToggle");
const navMenu = document.getElementById("navMenu");

menuToggle.addEventListener("click", () => {
  const isOpen = navMenu.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "✕" : "☰";
});

document.querySelectorAll("#navMenu a").forEach((link) => {
  link.addEventListener("click", () => {
    navMenu.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("contactButton").addEventListener("click", async () => {
  const contactText = "Email: emailkamu@example.com | GitHub: github.com/usernamekamu";
  const message = document.getElementById("copyMessage");
  try {
    await navigator.clipboard.writeText(contactText);
    message.textContent = "Teks kontak berhasil disalin. Ganti dengan kontak milikmu di index.html.";
  } catch (error) {
    message.textContent = "Salin kontak ini secara manual: " + contactText;
  }
});
